import axios from 'axios';

const axiosInstance = axios.create({
    baseURL: 'http://localhost:8000', // URL base del backend
    withCredentials: true, // Permitir el envío de cookies
});

// Interceptor para incluir el token de acceso en las solicitudes
axiosInstance.interceptors.request.use((config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Manejar errores globales (opcional)
axiosInstance.interceptors.response.use(
    (response) => response,
    (error) => {
        // Por ejemplo: Redirigir al login si el token expira
        if (error.response && error.response.status === 401) {
            // Manejar error de autenticación aquí
        }
        return Promise.reject(error);
    }
);

export default axiosInstance;
